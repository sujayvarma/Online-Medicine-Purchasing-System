<!DOCTYPE html>
<html>
<head>
 <title>Payment</title>
<style>
input[type="submit"]{
align:center;
}
BlackBorder
{
border: 2px solid  #8FD8D2;
border-radius: 15px;
background-color: #8FD8D2;
color:#DF744A;
}
abc{
width:200px;
height:40px;
}</style>
</head>
<body>
<p align="center"><center><h3>Please provide following details<center></h3></p>
<form name="myForm" action="" onsubmit="return validateForm()" method="post">
 <table align="center"  class="roundtable" width="466" height="180px" cellpadding="5px" cellspacing="5px" border="5px" border-radius="10px">
<tr  >
	<td width="130" class="BlackBorder" height="8px" background-color=" #8FD8D2"><b> Username</b></td>
<td width="313"> <input type="text" name="t1" required pattern="^[A-Za-z0-9]+" class="abc" style="background-color: #FEDCD2"></td></tr><tr>
<td width="130" class="BlackBorder" height="8px" ><b> Password</b></td>
<td width="313"> <input type="password" name="t2" required pattern="^[A-Za-z0-9]+" class="abc" style="background-color: #FEDCD2"></td></tr>

 </table><br>
    <input type="submit" name="submit1" value="Submit" allign="center" style="font-size:13pt;color:black;background-color:#BFD8D2;border:2px solid #BFD8D2;border-radius:5px";align:"center";padding:3px;margin-left: 50%" width="20px" height="20px">

</form>


<?php
if(isset($_POST["submit1"]))
{
$pwd=md5($_POST["t2"]);
$link=mysqli_connect("localhost","root","");
mysqli_select_db($link,"loginregister");
$count=0;
$res=mysqli_query($link,"select * from registration where username='$_POST[t1]'&& password='$pwd'");
$count=mysqli_num_rows($res);
if ($count==0)
{
?>
<script type="text/javascript">
alert("No Such User Exists");
</script>
<?php
}
else
{
?>
<script type="text/javascript">
alert("Sucessfully logged in");
</script>
<?php
}

}
?>
</body>
</html>