<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Medical Store</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<style>
		input[type="submit"] {
			width: 200px;
			height: 50px;
			background-color: #0C8613;
			font-family:arial;
			font-size: 25px;
			color: white;
		}
		
		.roundtable{
			border-top: 2px  solid black;
						border-left: 5px  solid black;
			border-right: 5px  solid black;

			border-bottom: 5px solid black;
			
				
		}
		.abc{width: 300px;
			height: 60px;
		}
		.BlackBorder {
border: 2px solid  #D1F2EB;
			border-radius: 15px;
			background-color: #D1F2EB;
			font-size: 23px;
}
		.BlackBord {
			width: 150px;
border: 2px solid #F9E79F;
			
			background-color: #F9E79F;
}
		.imi{
			border-top: 5px  solid black;
						border-left: 5px  solid black;
			border-right: 5px  solid black;

			border-bottom: 2px solid black;
			background-color:#0C8613;
			font-family:arial;
			font-size: 25px;
			color: white;
		}
	</style>
</head>

<body>
<table align="center" border="5px" border-radius="10px" width="472" class="imi"><tr><td align="center"><br>NEW REGISTRATION!!!<br><br></td></tr></table>
<form name="form1" action="" method="POST">
  <table align="center"  class="roundtable" width="466" height="450px" cellpadding="5px" cellspacing="5px">
    
    <tr  >
	<td width="126" class="BlackBorder" height="10px" align="center"><b> Firstname</b></td>
<td width="313"><input type="text" name="t1" required pattern="^[A-Za-z]+" class="abc" style="background-color: #F9E79F" oninvalid="setCustomValidity('Name must contain alphabets only')"></td>
</tr>
<tr>
<td class="BlackBorder" align="center"><b>Lastname</b></font></td>
<td ><input type="text" width name="t2" required pattern="^[A-Za-z]+"  class="abc" style="background-color: #F9E79F" oninvalid="setCustomValidity('Surname must contain alphabets only')"></td>
</tr>
<tr>
<td class="BlackBorder" align="center"><b> Username</b></font></td>
<td><input type="text" name="t3" required pattern="^[A-Za-z0-9]+"  class="abc" style="background-color: #F9E79F" oninvalid="setCustomValidity('Username must contain alphabets and digits only')"></td>
</tr>
<tr>
<td class="BlackBorder" align="center"><b> Password</b><br><font size=2px>(min 4 characters starting with letter)</font></td>
<td><input type="password" name="t4" required pattern="^[a-zA-Z]\w{3,14}$"  class="abc" style="background-color: #F9E79F" oninvalid="setCustomValidity('Password must be min 3 characters long)"></td>
</tr>
<tr>
<td class="BlackBorder" align="center"><br><b> Gender</b></font></td>
<td class="BlackBord"><input type="radio" name="r1" value="male" checked><font size="3"><b>Male</b></font><input type="radio" name="r1" value="female"><font size="3"><b>Female</b></font></td>
</tr>
<tr>
<td colspan="2" align="center" >
<input type="submit" name="submit1" value="submit">
</td>
</tr>
</table>
</form>
	
<?php
if(isset($_POST["submit1"]))
{
$link=mysqli_connect("localhost","root","");
mysqli_select_db($link,"loginregister");
$count=0;
$res=mysqli_query($link,"select * from registration where username='$_POST[t3]'");
$count=mysqli_num_rows($res);
if ($count>0)
{
?>
<script type="text/javascript">
alert("Username alredy exists");
</script>
<?php
}
else
{
$pwd=md5($_POST["t4"]);
mysqli_query($link,"insert into registration values('','$_POST[t1]','$_POST[t2]','$_POST[t3]','$pwd','$_POST[r1]')");
?>

<script type="text/javascript">
alert("Record inserted successfully");

</script>


<?php
	
	header('Location:http://localhost/registrationlogin/main.html');
//	echo "Record inserted successfully";
}
}

?>
</body>
</html>