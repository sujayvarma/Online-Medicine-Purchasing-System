<?php
if(isset($_POST['submit'])){
		$name =$_FILES['myfile']['name'];
	$tmp_name =$_FILES['myfile']['tmp_name'];
	
	if($name ){
		$location="uploads/$name";
		move_uploaded_file($tmp_name,$location);
		$query=mysql_query("INSERT INTO uploads (name,path) VALUES ('$name','$location')");
		header('Location:medicine.php');
echo "XYZ";
                    
	}else
		die("please select a file");
}
?>