<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Medical Store</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<style>
		img {
border-radius: 50%;
border-style: solid;
border-width: 3px;
box-shadow: 20px 20px 20px gray;
			margin:200px;}
		input[type="submit"] {
			width: 200px;
			height: 50px;
			background-color:#0C8613;
			font-family:arial;
			font-size: 25px;
			color: white;
		}
		.BlackBorder {
border: 4px solid  #0C8613;
			border-radius: 5px;
			font-size: 23px;
			box-shadow: 20px 20px 20px gray;
}
		.Abcd{
			width=450px;
			background-color: #24C741;
			color:white;
			font-family:"arial";
		}
		.abc{width: 500px;
			height: 30px;
			margin:5px;
			border-color: #0C8613;
		}
	</style>
</head>


<body ><br><br><br>        
<form name="form1" action="main.html" method="post">
<table align="center"><tr>
  <td>
<table width="500px" height="174" cellspacing="0" class="BlackBorder">
<tr>
	<td align="center" class="Abcd"><b>Enter Username</b></td></tr><tr><td>
	<input type="text" name="t1" class="abc" required pattern="^[A-Za-z0-9]+" align="absmiddle" style="border-color:#0C8613;"></td>
	</tr><tr>
	<td align="center" class="Abcd"><b>Enter Password</b></td></tr><tr>
<td><input type="password" name="t2" class="abc" required pattern="^[A-Za-z0-9$&*#()]+" style="border-color:#0C8613;"></td>
</tr>
<td height="48" colspan="2" align="center">
<input type="submit" name="submit1" value="Submit">
</td>
</tr>
</table>
</form>

<?php
if(isset($_POST["submit1"]))
{
$link=mysqli_connect("localhost","root","");
mysqli_select_db($link,"loginregister");
$count=0;
$res=mysqli_query($link,"select * from registration where username='$_POST[t3]'");
$count=mysqli_num_rows($res);
echo $count;
if ($count>0)
{
?>
<script type="text/javascript">
window.location="main.html";
</script>
<?php
}


else
{
?>
<script type="text/javascript">
alert("incorrect username or password");
</script>
<?php
}
}
?>
</body>
</html>