<!DOCTYPE html>
<html>
<head>
 <title>Payment</title>
<style>
input[type="submit"]{
align:center;
}
BlackBorder
{
border: 2px solid  #8FD8D2;
border-radius: 15px;
background-color: #8FD8D2;
color:#DF744A;
}
abc{
width:200px;
height:40px;
}</style>
</head>
<body>
<p align="center"><center><h3>Please provide your visa card details<center></h3></p>
<form name="myForm" action="" onsubmit="return validateForm()" method="post">
 <table align="center"  class="roundtable" width="466" height="180px" cellpadding="5px" cellspacing="5px" border="5px" border-radius="10px">
<tr  >
	<td width="130" class="BlackBorder" height="8px" background-color=" #8FD8D2"><b> CARD NO</b></td>
<td width="313"> <input type="text" name="t1"  pattern="[4][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]" class="abc" style="background-color: #FEDCD2" oninvalid="setCustomValidity('Plz enter valid CARD NUMBER')" /></td></tr><tr>
<td width="130" class="BlackBorder" height="8px" ><b> CVV</b></td>
<td width="313"> <input type="password" name="t2"  pattern="[0-9][0-9][0-9]" class="abc" style="background-color: #FEDCD2" oninvalid="setCustomValidity('Plz enter valid CVV NUMBER')"></td></tr>

 </table><br>
    <input type="submit" name="submit1" value="Submit" allign="center" style="font-size:13pt;color:black;background-color:#BFD8D2;border:2px solid #BFD8D2;border-radius:5px";align:"center";padding:3px;margin-left: 50%" width="20px" height="20px">

</form>


<?php
if(isset($_POST["submit1"]))
{
$mvv=md5($_POST["t2"]);
$pvv=md5($_POST["t2"]);
$link=mysqli_connect("localhost","root","");
mysqli_select_db($link,"card");
mysqli_query($link,"insert into credit values('$mvv','$pvv')");
?>
<script type="text/javascript">
alert("Thanks for shopping!!! Your order will be delivered shortly!")
</script>
<?php

}


?>
</body>
</html>