<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Login</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<form name="form1" action="" method="post">
<table>
<tr>
<td>USERNAME</TD>
<TD><INPUT TYPE="TEXT" NAME="T1" required pattern="^[A-Za-z0-9]+"></TD>
</TR>
<tr>
<td>PASSWORD</TD>
<TD><INPUT TYPE="PASSWORD" NAME="T2" required pattern="^[A-Za-z0-9]+"></TD>
</TR>
<TR>
<TD COLSPAN="2" ALIGN="CENTER"><INPUT TYPE="SUBMIT" NAME="SUBMIT1" VALUE="LOGIN"></TD></TR>
</TABLE>
</FORM>

<?php
if(isset($_POST["submit1"]))
{
$link=mysqli_connect("localhost","root","");
mysqli_select_db($link,"loginregister");
$count=0;
$res=mysqli_query($link,"select * from registration where username='$_POST[t1]'");
$count=mysqli_num_rows($res);
if ($count==0)
{
?>
<script type="text/javascript">
alert("No Such User Exists");
</script>
<?php
}
}
?>
</body>
</html>