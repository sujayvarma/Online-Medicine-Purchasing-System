<?php
echo "no access";
?>